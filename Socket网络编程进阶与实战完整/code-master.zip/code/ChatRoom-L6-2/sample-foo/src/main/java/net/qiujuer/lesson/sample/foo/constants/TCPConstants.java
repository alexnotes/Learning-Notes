package net.qiujuer.lesson.sample.foo.constants;

public class TCPConstants {
    // 服务器固化UDP接收端口
    public static int PORT_SERVER = 30401;
}
