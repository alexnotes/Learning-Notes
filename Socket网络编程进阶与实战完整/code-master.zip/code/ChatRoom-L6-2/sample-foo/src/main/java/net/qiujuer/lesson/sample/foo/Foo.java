package net.qiujuer.lesson.sample.foo;

public class Foo {
}
